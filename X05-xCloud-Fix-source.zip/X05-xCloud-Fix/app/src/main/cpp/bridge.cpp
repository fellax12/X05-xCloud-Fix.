#include <jni.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <dirent.h>
#include <atomic>
#include <thread>
#include <string>
#include <cstring>
#include <cstdio>

static std::atomic<bool> running(false);
static int src=-1, ui=-1;
static std::thread worker;

static void emit(int type,int code,int value){ input_event e{}; e.type=type;e.code=code;e.value=value; write(ui,&e,sizeof(e)); }
static bool idMatches(int fd){ input_id id{}; if(ioctl(fd,EVIOCGID,&id)<0)return false; return id.bustype==BUS_BLUETOOTH && id.vendor==0x045e && id.product==0x02e0; }
static std::string findX05(){ DIR*d=opendir("/dev/input"); if(!d)return {}; dirent*e; while((e=readdir(d))){ if(strncmp(e->d_name,"event",5))continue; std::string p="/dev/input/"+std::string(e->d_name); int f=open(p.c_str(),O_RDONLY|O_NONBLOCK); if(f>=0){ if(idMatches(f)){close(f);closedir(d);return p;} close(f);} } closedir(d);return {}; }
static bool createPad(){ ui=open("/dev/uinput",O_WRONLY|O_NONBLOCK); if(ui<0)return false;
 ioctl(ui,UI_SET_EVBIT,EV_KEY); int keys[]={BTN_SOUTH,BTN_EAST,BTN_WEST,BTN_NORTH,BTN_TL,BTN_TR,BTN_SELECT,BTN_START,BTN_THUMBL,BTN_THUMBR,BTN_MODE}; for(int k:keys)ioctl(ui,UI_SET_KEYBIT,k);
 ioctl(ui,UI_SET_EVBIT,EV_ABS); int axes[]={ABS_X,ABS_Y,ABS_RX,ABS_RY,ABS_Z,ABS_RZ,ABS_HAT0X,ABS_HAT0Y}; for(int a:axes)ioctl(ui,UI_SET_ABSBIT,a);
 uinput_setup us{}; snprintf(us.name,UINPUT_MAX_NAME_SIZE,"Microsoft X-Box 360 pad"); us.id.bustype=BUS_USB;us.id.vendor=0x045e;us.id.product=0x028e;us.id.version=0x0114; if(ioctl(ui,UI_DEV_SETUP,&us)<0)return false;
 auto abs=[&](int c,int mn,int mx,int flat){uinput_abs_setup s{};s.code=c;s.absinfo.minimum=mn;s.absinfo.maximum=mx;s.absinfo.flat=flat;ioctl(ui,UI_ABS_SETUP,&s);};
 abs(ABS_X,-32768,32767,4096);abs(ABS_Y,-32768,32767,4096);abs(ABS_RX,-32768,32767,4096);abs(ABS_RY,-32768,32767,4096);abs(ABS_Z,0,255,0);abs(ABS_RZ,0,255,0);abs(ABS_HAT0X,-1,1,0);abs(ABS_HAT0Y,-1,1,0);
 return ioctl(ui,UI_DEV_CREATE)>=0; }
static int scaleStick(int v){ long x=((long)v*65535L)/65535L-32768L; if(x<-32768)x=-32768;if(x>32767)x=32767;return (int)x; }
static int scaleTrigger(int v){ if(v<0)v=0;if(v>1023)v=1023;return v*255/1023; }
static void loop(){ input_event e{}; while(running){ ssize_t n=read(src,&e,sizeof(e)); if(n!=sizeof(e)){usleep(1000);continue;} if(e.type==EV_KEY){ switch(e.code){case BTN_SOUTH:case BTN_EAST:case BTN_WEST:case BTN_NORTH:case BTN_TL:case BTN_TR:case BTN_SELECT:case BTN_START:case BTN_THUMBL:case BTN_THUMBR:case BTN_MODE: emit(EV_KEY,e.code,e.value);break;} }
 else if(e.type==EV_ABS){ int v=e.value; switch(e.code){case ABS_X:case ABS_Y:case ABS_RX:case ABS_RY:v=scaleStick(v);emit(EV_ABS,e.code,v);break;case ABS_Z:case ABS_RZ:v=scaleTrigger(v);emit(EV_ABS,e.code,v);break;case ABS_HAT0X:case ABS_HAT0Y:emit(EV_ABS,e.code,v);break;} } else if(e.type==EV_SYN) emit(EV_SYN,e.code,e.value); } }
static std::string start(){ if(running)return "Bridge já está ativo."; auto p=findX05(); if(p.empty())return "ERRO: X05 045e:02e0 não encontrado em /dev/input."; src=open(p.c_str(),O_RDONLY|O_NONBLOCK);if(src<0)return "ERRO: não foi possível abrir "+p; int one=1;if(ioctl(src,EVIOCGRAB,one)<0){close(src);src=-1;return "ERRO: EVIOCGRAB bloqueado pelo sistema. O virtual não foi iniciado para evitar entrada dupla.";} if(!createPad()){ioctl(src,EVIOCGRAB,0);close(src);src=-1;if(ui>=0)close(ui);ui=-1;return "ERRO: falha ao criar Xbox virtual em /dev/uinput.";} running=true;worker=std::thread(loop);return "OK: X05 capturado em "+p+"\nOK: EVIOCGRAB ativo\nOK: Microsoft X-Box 360 pad virtual criado\nAbra o HardwareTester e teste B0–B15."; }
static std::string stop(){ if(!running && src<0)return "Bridge já está parado.";running=false;if(worker.joinable())worker.join();if(ui>=0){ioctl(ui,UI_DEV_DESTROY);close(ui);ui=-1;}if(src>=0){ioctl(src,EVIOCGRAB,0);close(src);src=-1;}return "Correção desativada e X05 liberado."; }
extern "C" JNIEXPORT jstring JNICALL Java_com_x05fix_service_BridgeService_nativeStart(JNIEnv*e,jobject){auto s=start();return e->NewStringUTF(s.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_x05fix_service_BridgeService_nativeStop(JNIEnv*e,jobject){auto s=stop();return e->NewStringUTF(s.c_str());}
