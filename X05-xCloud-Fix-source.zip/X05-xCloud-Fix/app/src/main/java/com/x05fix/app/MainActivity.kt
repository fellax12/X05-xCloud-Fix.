package com.x05fix.app

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.x05fix.service.BridgeService
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private var svc: BridgeService? = null
    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, BridgeService::class.java.name))
            .daemon(false).processNameSuffix("x05bridge").debuggable(BuildConfig.DEBUG).version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = binder as? BridgeService
            status.text = "Shizuku ativo • serviço UID shell conectado"
        }
        override fun onServiceDisconnected(name: ComponentName?) { svc = null; status.text = "Serviço desconectado" }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); log=findViewById(R.id.log)
        findViewById<Button>(R.id.start).setOnClickListener { log.text = svc?.startBridge() ?: "Serviço ainda não conectado." }
        findViewById<Button>(R.id.stop).setOnClickListener { log.text = svc?.stopBridge() ?: "Serviço não conectado." }
        setupShizuku()
    }
    private fun setupShizuku() {
        if (!Shizuku.pingBinder()) { status.text="Inicie o Shizuku primeiro."; return }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) bind()
        else Shizuku.requestPermission(41)
        Shizuku.addRequestPermissionResultListener { code, grant -> if(code==41 && grant==PackageManager.PERMISSION_GRANTED) bind() else status.text="Permissão Shizuku negada" }
    }
    private fun bind() { status.text="Conectando serviço…"; Shizuku.bindUserService(args, conn) }
    override fun onDestroy() { super.onDestroy() }
}
