package com.x05fix.service

import android.os.Binder

class BridgeService : Binder() {
    companion object { init { System.loadLibrary("x05bridge") } }
    private external fun nativeStart(): String
    private external fun nativeStop(): String
    fun startBridge(): String = nativeStart()
    fun stopBridge(): String = nativeStop()
}
